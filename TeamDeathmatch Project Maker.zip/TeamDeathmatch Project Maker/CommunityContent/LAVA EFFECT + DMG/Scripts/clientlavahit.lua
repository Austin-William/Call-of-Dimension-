local LAVAEFFECT = script:GetCustomProperty("LAVAEFFECT")

--function OnPlayerLAVAEFFECT(player)
--		local playerPos = player:GetWorldPosition()
--		World.SpawnAsset(LAVAEFFECT, {position = playerPos})
--end

-- Initialize
--Events.Connect("PlayerLAVAEFFECT", OnPlayerLAVAEFFECT)